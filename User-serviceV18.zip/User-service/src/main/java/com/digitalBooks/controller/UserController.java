package com.digitalBooks.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.digitalBooks.booksHelper.BooksList;
import com.digitalBooks.components.Book;
import com.digitalBooks.components.User;
import com.digitalBooks.controller.apiHelper.HttpComponentsClientHttpRequestWithBodyFactory;
import com.digitalBooks.service.UserService;


@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	RestTemplate resTemplate;
	
	@GetMapping("/{userId}")
	public ResponseEntity<Object> getUser(@PathVariable("userId") int userId)
	{
		
			User user = userService.getUser(userId);
			return new org.springframework.http.ResponseEntity<>(user, HttpStatus.OK);
		
	}
	
	@PostMapping("/create")
	public ResponseEntity<User> createUser(@RequestBody User user) {
		System.out.println(user.getUserName());
		return ResponseEntity.status(HttpStatus.CREATED).body((userService.createUser(user)));
		
	}
	
	@GetMapping("/find")
	public ResponseEntity<Object> getUserByNameAndPassword(@RequestBody  User loginUser)
	{
		
			Optional<User> user = userService.getUserByUserNameAndPassword(loginUser.getUserName(), loginUser.getPassword());
			if(user.isPresent()) {
				return new org.springframework.http.ResponseEntity<>(user.get(), HttpStatus.OK);
				
			}else {
				return new org.springframework.http.ResponseEntity<>("Not found", HttpStatus.NOT_FOUND);
			}
			
		
	}
	//For create book 
	@PostMapping("/create/book")
	public HttpStatus createBook(@RequestBody Book book) {
		//System.out.println(user.getUserName());
		HttpEntity<Book> request = new HttpEntity<>(new Book(book));
		
		resTemplate.exchange("http://Book-service/book/create", HttpMethod.POST, request,  String.class);
		return HttpStatus.CREATED;
		
	}
	
	//For put book 
		@PutMapping("/update/book")
		public HttpStatus updateBook(@RequestBody Book book) {
			
			HttpEntity<Book> request = new HttpEntity<>(new Book(book));
			
			resTemplate.exchange("http://Book-service/book/update", HttpMethod.PUT, request,  String.class);
			return HttpStatus.OK;
			
		}
		

		//For get book
			@GetMapping("/search/book")
			public ResponseEntity<Book> getBook(@RequestBody Book book) {
				
				//Book searchedbook =resTemplate.getForObject("http://Book-service/book/search", Book.class);
				//return ResponseEntity.status(HttpStatus.CREATED).body(searchedbook);
//				Map<String, String> params = new HashMap<String, String>();
//				params.put("author", "1");
//				params.put("bookTitle","Mahabharata"); 
//
//				//Parse the string after getting the response
//				Book searchedbook = resTemplate.getForObject("http://Book-service/book/search", Book.class, params);
				
				
				//HttpEntity<Book> request = new HttpEntity<>(new Book(book));
				resTemplate.setRequestFactory(new HttpComponentsClientHttpRequestWithBodyFactory());
				ResponseEntity<Book> searchedbook = resTemplate.exchange("http://Book-service/book/search",HttpMethod.GET, new HttpEntity<>(book),  Book.class);
				return searchedbook;
				
				
			}
			//Get all subscribed books by reader	WIP
			@GetMapping("/searchBySubsId")
			public List<Book> getUser(@RequestParam String subsciberId, @RequestParam String userName)
			{
				Map<String, String> params = new HashMap<String, String>();
				params.put("subsciberId", "1");
				params.put("userName", "aviansh");
				
				BooksList  response = resTemplate.getForObject("http://Book-service/book/SubsciberSearch"+"/subsciberId"+ "/userName", BooksList.class);
				List<Book> searchedBooks = response.getBooks();
					return searchedBooks;
				
			}
			
			
			
//			Map<String, String> vars = new HashMap<>();
//			vars.put("hotel", "42");
//			vars.put("room", "21");
//
//			restTemplate.getForObject("http://example.com/hotels/{hotel}/rooms/{room}", 
//			    String.class, vars);
//			
	
//	Map<String, String> params = new HashMap<String, String>();
//	params.put("id", "1");
//
//	User user = restTemplate.getForObject(URI_USERS_ID, User.class, params);
	
	
	//Put
	
//	Map<String, String> params = new HashMap<String, String>();
//	params.put("id", "2");
//
//	User updatedUser = new User(1, "Alex", "Golan", "a@mail.com");
//	User user = restTemplate.put(URI_USERS_ID, updatedUser, User.class);
}
