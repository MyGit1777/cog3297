
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class DriverClass {
    public DriverClass() {
    }

    public static void main(String[] args) {
        Display display = new Display() {
            public void show() {
                System.out.println("This is an implementaion for show method");
            }
        };
        display.show();
        Display displayUsingLambda = () -> {
            System.out.println(" This is a show method call using lambda");
        };
        displayUsingLambda.show();
        List<Integer> intList = Arrays.asList(1, 4, 5, 6, 7, 78, 78, 7453, 33, 2, 2, 33);
        Iterator listIterator = intList.iterator();

        while(listIterator.hasNext()) {
            System.out.println(listIterator.next());
        }
        

        MyConsumer myConsumer = new MyConsumer();
        intList.forEach((e) -> {
            myConsumer.accept(e);
        });
        System.out.println("----------------------------------Streams");
        Stream<Integer> intSeriealStream = intList.stream();
        Stream<Integer> intParallelStream = (Stream)intList.stream().parallel();
        Stream<Integer> highNos = intParallelStream.filter((f) -> {
            return f > 89;
        });
        System.out.println("High nos in the list with parallel stream");
        highNos.forEach((no) -> {
            System.out.println(no);
        });
        Stream<Integer> highNosInserialOrder = intSeriealStream.filter((f) -> {
            return f > 2;
        });
        System.out.println("High nos in the sequesnce");
        highNosInserialOrder.forEach((no) -> {
            System.out.println(no);
        });
        System.out.println("----------------------------------Date and Time API");
        LocalDate localDate = LocalDate.now();
        System.out.println("Today " + localDate);
        System.out.println("EPOCH day " + LocalDate.EPOCH);
        System.out.println("UTC day " + LocalDate.now(ZoneId.of("UTC")));
        System.out.println("----------------------------------Optional class");
        String[] strArray = new String[5];
        strArray[0] = "This is a string 0";
        Optional<String> strOptional = Optional.ofNullable(strArray[0]);
        Optional<String> strOptional1 = Optional.of(strArray[1]);
        System.out.println("Checking emptyness of the string: " + strOptional.isEmpty());
        System.out.println("Checking emptyness of the string: " + strOptional1.isEmpty());
        if (strOptional.isPresent()) {
            System.out.println(((String)strOptional.get()).toUpperCase());
        } else {
            System.err.println("String is not present, adding new string");
            strArray[0] = "This is default added";
        }

        Consumer<String> displayConsumer = (str) -> {
            System.out.println(str);
        };
        strOptional.ifPresentOrElse((str) -> {
            System.out.println("String is present");
        }, () -> {
            System.out.println("String is not present");
        });
    }
}
