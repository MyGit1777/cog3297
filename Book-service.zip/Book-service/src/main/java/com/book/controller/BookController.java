package com.book.controller;



import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.components.Book;
import com.book.service.BookService;


@ComponentScan
@RestController
@RequestMapping("/book")
public class BookController {
	
	@Autowired
	private BookService bookService;
	
	@GetMapping("/{authorId}")
	public List<Book> getUser(@PathVariable("authorId") int authorId) {//replace with json
		
		List<Book> books = bookService.getBooks(authorId);
		return books.stream().filter(e->e.getAuthorId()==authorId).collect(Collectors.toList());
		
		
	}
}
