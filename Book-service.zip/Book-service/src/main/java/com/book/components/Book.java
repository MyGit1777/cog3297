package com.book.components;


public class Book {
	private int authorId;
	private String bookTitle;
	private String category;
	
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	private int price;
	private String status;
	
	
	public Book(int authorId, String bookTitle, String category, int price, String status) {
		super();
		this.authorId = authorId;
		this.bookTitle = bookTitle;
		this.category = category;
		this.price = price;
		this.status = status;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
