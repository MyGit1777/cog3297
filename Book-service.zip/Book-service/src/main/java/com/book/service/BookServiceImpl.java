package com.book.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.book.components.Book;

@Service
public class BookServiceImpl implements BookService{

	@Override
	public List<Book> getBooks(int authorId) {
		
		List<Book> books = new ArrayList<Book>();
		Book book1 = new Book(12, "Rich dad poor dad", "Economical", 500, "Active");
		Book book2 = new Book(15, "XYZ", "Fiction", 400, "Inactive");

		books.add(book1);
		books.add(book2);

		
		return books.stream().filter(e->e.getAuthorId()== authorId).collect(Collectors.toList());
	}

}
