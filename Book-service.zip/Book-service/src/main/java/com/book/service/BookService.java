package com.book.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.book.components.Book;

public interface BookService {

	public List<Book> getBooks(int authorId);
}
