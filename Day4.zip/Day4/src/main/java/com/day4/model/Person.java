package com.day4.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Person {
	
	public Person() {
		super();
	}

	@Id
	private int personId;
	private String personName;

	public int getPersonId() {
		return personId;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public Person(int personId, String personName) {
		super();
		this.personId = personId;
		this.personName = personName;
	}

}
