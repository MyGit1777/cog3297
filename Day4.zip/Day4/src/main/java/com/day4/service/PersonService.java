package com.day4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.day4.model.Person;
import com.day4.repository.PersonRepository;

@Service
public class PersonService {

	@Autowired
	private PersonRepository personRepo;

	public List<Person> getAllPersons() {

		return this.personRepo.findAll();
	}

	public PersonService(PersonRepository personRepo) {
		super();
		this.personRepo = personRepo;
	}

}
