package com.Day4.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.day4.repository.PersonRepository;
import com.day4.service.PersonService;

@ExtendWith(MockitoExtension.class)
class PersonServiceTestUsingMockito {
	@Mock
	private PersonRepository personRepository;

	private PersonService personService;

	@BeforeEach
	void setUp() {
		this.personService = new PersonService(this.personRepository);
	}

	@Test
	void getAllPerson() {

		personService.getAllPersons();

		verify(personRepository).findAll();

	}
}