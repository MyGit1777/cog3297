package com.Day4.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.day4.model.Person;
import com.day4.repository.PersonRepository;

@SpringBootTest
class PersonServiceTest1 {

	@Autowired
	private PersonRepository personRepository;
	@Test
	void isPesronExitsById() {
		Person person=new Person(18,"sachin");
		try {
			personRepository.save(person);
		}catch(Exception e) {
			
			System.out.println("saved"+ e);
		}
		
		Boolean acRes=personRepository.isPersonExisting(18);
		assertThat(acRes).isTrue();
	}
	
	@BeforeEach
	void setUp() {
		System.out.println(" Setup is started");
	}
//	@AfterEach
//	void tearDown() {
//		System.out.println(" Test Over");
//		personRepository.deleteAll();
//	}

}
