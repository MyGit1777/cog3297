package com.Day8DepartmentService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class Day8DepartmentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day8DepartmentServiceApplication.class, args);
	}
}
