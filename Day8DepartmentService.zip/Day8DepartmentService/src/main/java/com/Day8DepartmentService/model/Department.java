package com.Day8DepartmentService.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import ch.qos.logback.core.joran.spi.NoAutoStart;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class Department {
	@Id
	private long deptId;
	private String deptName;

	private String deptAddress;

	private String deptCode;


}
