package com.Day8DepartmentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day8DepartmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
