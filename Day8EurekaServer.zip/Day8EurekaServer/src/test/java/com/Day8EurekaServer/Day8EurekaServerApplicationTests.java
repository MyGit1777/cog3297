package com.Day8EurekaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day8EurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
