package com.Day7ContactService.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.Day7ContactService.model.Contact;

@Service
public class ContactServiceImpl implements ContactService{
	public static List<Contact> contacts = List.of(new Contact(12, "avinash@gmail.com", 15L),
			new Contact(12, "Silva@gmail.com", 35L),
			new Contact(14, "Ram@yahoo.com", 24L),
			new Contact(18, "Marc@yahoo", 36L),
			new Contact(19, "Vincent@gmail", 55L));
	
	
	@Override
	public List<Contact> getContactsOfUser(int userId) {
	
			 
					List<Contact> cList = contacts.stream().filter(user->user.getId()==userId).collect(Collectors.toList());
					
					return cList;
			}

}
