package com.Day7ContactService.service;

import java.util.List;

import com.Day7ContactService.model.Contact;

public interface ContactService {
	public List<Contact> getContactsOfUser(int userId);
	
	

}
