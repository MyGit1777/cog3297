package com.Day7ContactService.model;

public class Contact {

	private int id;
	private String email;
	private Long age;

	public Contact(int id, String email, Long age) {
		super();
		this.id = id;
		this.email = email;
		this.age = age;
	}

	public Contact() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getAge() {
		return age;
	}

	public void setAge(Long age) {
		this.age = age;
	}

}
