package com.Day7ContactService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day7ContactServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
