package com.Day7UserService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day7UserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
