package com.Day7UserService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.Day7UserService.model.Contact;
import com.Day7UserService.model.User;
import com.Day7UserService.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userservice;

	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/{userId}")
	public User getUser(@PathVariable int userId) {
		//return this.userservice.getUser(userId);
		
		
		User user = this.userservice.getUser(userId);
		List<Contact> contacts = restTemplate.getForObject("http://localhost:8185/contact/user/" + userId, List.class);
		user.setContacts(contacts);
		return user;
	}
}


