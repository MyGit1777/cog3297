package com.Day7UserService.service;

import com.Day7UserService.model.User;


public interface UserService {
	
	public User getUser(int userId);
}
