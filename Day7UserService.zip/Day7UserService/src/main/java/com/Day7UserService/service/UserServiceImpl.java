package com.Day7UserService.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Day7UserService.model.User;

@Service
public class UserServiceImpl implements UserService
{

	
	List<User> users = List.of(new User(12, "avinash", "879354"),
			new User(12, "avinash", "879354"),
			new User(14, "Ram", "879354"),
			new User(18, "Marc", "879354"),
			new User(19, "Vincent", "879354"));
	@Override
	public User getUser(int userId) {


		return users.stream().filter(user->user.getUserId()==userId).findAny().orElse(null);
	}

}
