package com.Day12ALogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day12ALoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
