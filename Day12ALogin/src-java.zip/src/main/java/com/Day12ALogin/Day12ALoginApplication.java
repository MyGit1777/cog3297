package com.Day12ALogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day12ALoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day12ALoginApplication.class, args);
	}

}
