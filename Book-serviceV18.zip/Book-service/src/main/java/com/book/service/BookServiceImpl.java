package com.book.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.components.Book;
import com.book.components.User;
import com.book.repository.BooksRepository;

@Service
public class BookServiceImpl implements BookService{
	@Autowired
	private BooksRepository booksRepo;

//	@Override
//	public List<Book> getBooks(int authorId) {
		
//		List<Book> books = new ArrayList<Book>();
//		Book book1 = new Book(12, "Rich dad poor dad", "Economical", 500, "Active");
//		Book book2 = new Book(15, "XYZ", "Fiction", 400, "Inactive");

//		books.add(book1);
//		books.add(book2);

		//return books.stream().filter(e->e.getAuthorId()== authorId).collect(Collectors.toList());
	//}

	
	@Override
	public Book searchBook(Book book) {
		
		return null;
	}

	@Override
	public List<Book> getAllBooksSubscribedByUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int subscribeBook(Book book, User user) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String createBook(Book book) {
		
		booksRepo.save(book);
		return "CREATED";
	}

	@Override
	public String updateBook(Book book) {
		
//		Book oldBook = new Book(book);
//		oldBook.setAuthorId(booksRepo.findBookByAuthorId(book.getAuthorId()).getAuthorId());
//		book.setActive(oldBook.getActive());
		
		booksRepo.save(book);
		return "UPDATED";
	}

	//Get all books for geust, author and reader
	@Override
	public List<Book> getAllBooks(Book book) {
		List<Book> books = booksRepo.findAll();
		return books;
	}

	@Override
	public Book findBookByAuthorId(int authorId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book searchBookByTitleAndAuthorName(Book book) {
		//book.getBookTitle(), book.getAuthor()
		Book searchedBook = booksRepo.searchBookByTitleAndAuthor(book.getBookTitle(), book.getAuthor());
		return searchedBook;
	}
	
//	@Override
//	public Book findBookByAuthorId(int authorId) {
//		return booksRepo.getById(authorId);
//		
//		
//	}

	
}
