@FunctionalInterface
public interface Display {
    void show();
}
