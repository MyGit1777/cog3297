package com.cts;
import java.util.function.Consumer;

public class MyConsumer implements Consumer {

	@Override
	public void accept(Object t) {
		System.out.println(t);
	}
}
