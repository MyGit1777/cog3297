package com.cts;
public class FunctionalInterfaceAndLambdaPractice {

    public static void main(String[] args) {
    	
    	//Old way of doing with anonymous block
        Display display = new Display() {
            public void show() {
                System.out.println("This is an implementaion for show method");
            }
        };
        display.show();
        
        //Using lambda
        Display displayUsingLambda = () -> {
            System.out.println(" This is a show method call using lambda");
        };
        displayUsingLambda.show();                    
    }
}
