package com.cts;

import java.time.LocalDate;
import java.time.ZoneId;

public class DateAndTimeAPIPractice {

	public static void main(String[] args) {

		LocalDate localDate = LocalDate.now();
		System.out.println("Today " + localDate);
		System.out.println("EPOCH day " + LocalDate.EPOCH);
		System.out.println("UTC day " + LocalDate.now(ZoneId.of("UTC")));
		
		System.out.println("Adding year" + localDate.plusYears(3));
		System.out.println("Day of the year" + localDate.getDayOfYear());
		System.out.println("Day of the week " + localDate.getDayOfWeek());

	}

}
