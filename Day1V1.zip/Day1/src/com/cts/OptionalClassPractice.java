package com.cts;

import java.util.Optional;

public class OptionalClassPractice {

	public static void main(String[] args) {

		String[] strArray = new String[5];
		strArray[0] = "This is a string 0";

		Optional<String> strOptional = Optional.ofNullable(strArray[0]);

		System.out.println("Checking emptyness of the string: " + strOptional.isEmpty());

		if (strOptional.isPresent()) {
			System.out.println(((String) strOptional.get()).toUpperCase());
		} else {
			System.err.println("String is not present, adding new string");
			strArray[0] = "This is default added";
		}

		System.out.println(strOptional.isPresent());

		strOptional.ifPresentOrElse((str) -> {
			System.out.println("String is present");
		}, () -> {
			System.out.println("String is not present");
		});

	}

}
