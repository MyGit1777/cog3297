package com.cts;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamsPractice {

	public static void main(String[] args) {

		List<Integer> intList = Arrays.asList(1, 4, 5, 6, 7, 78, 78, 7453, 33, 2, 2, 33);
		
		intList.stream()
		.map(e -> e*2)
		.collect(Collectors.toList()).forEach(System.out::print);;
		
		Stream<Integer> intSeriealStream = intList.stream();
		Stream<Integer> intParallelStream = intList.stream().parallel();
		Stream<Integer> highNos = intParallelStream.filter((f) -> {
			return f > 89;
		});
		System.out.println("High nos in the list with parallel stream");
		highNos.forEach((no) -> {
			System.out.println(no);
		});
		Stream<Integer> highNosInserialOrder = intSeriealStream.filter((f) -> {
			return f > 2;
		});
		System.out.println("High nos in the sequesnce");
		highNosInserialOrder.forEach((no) -> {
			System.out.println(no);
		});

	}

}
