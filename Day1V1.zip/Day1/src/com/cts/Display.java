package com.cts;


@FunctionalInterface
public interface Display {
    void show();
}
