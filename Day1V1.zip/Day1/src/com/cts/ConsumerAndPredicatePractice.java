package com.cts;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class ConsumerAndPredicatePractice {

	public static void main(String[] args) {

		List<Integer> intList = Arrays.asList(1, 4, 5, 6, 7, 78, 78, 7453, 33, 2, 2, 33);
		Iterator<Integer> listIterator = intList.iterator();

		while (listIterator.hasNext()) {
			System.out.println(listIterator.next());
		}
		
		MyConsumer myConsumer = new MyConsumer();
		intList.forEach((e) -> {
			myConsumer.accept(e);
		});

		// Consumer chaining
		String[] strArray = { "Java", "Python", "Kotlin", "Ruby" };
		Consumer<String> consumerForUpperCase = (str) -> System.out.println(str.toUpperCase());
		Consumer<String> consumerAppendDev = (str) -> System.out.println(str + "-Developer");
		Stream.of(strArray).forEach(consumerForUpperCase.andThen(consumerAppendDev));
		
		
		// Predicate
		Predicate<Integer> isEven = (no) -> {return no%2 == 0;};
		intList.stream().filter(isEven).forEach(e-> System.out.println("Even numbers are: " + e));

	}
}
