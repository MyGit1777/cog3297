import java.util.function.Consumer;

public class MyConsumer implements Consumer {
    public MyConsumer() {
    }

    public void accept(Object t) {
        System.out.println(t);
    }
}
