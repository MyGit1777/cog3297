package com.Day8UserService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day8UserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
