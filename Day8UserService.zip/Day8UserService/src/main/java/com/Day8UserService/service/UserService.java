package com.Day8UserService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.Day8UserService.VO.Department;
import com.Day8UserService.VO.RestTemplateVO;
import com.Day8UserService.model.User;
import com.Day8UserService.repo.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	RestTemplate restTemplate;

	public User saveUser(User user) {

		log.info("Logging user service- save");

		return userRepo.save(user);

	}

	public RestTemplateVO getUserWithDept(Long userId) {

		RestTemplateVO restTemplateVO = new RestTemplateVO();
		User user = userRepo.findUByuserId(userId);
		Department department = restTemplate
				.getForObject("http://localhost:8187/department/" + user.getDepartmentId(), Department.class);

		restTemplateVO.setUser(user);
		restTemplateVO.setDepartment(department);
		return restTemplateVO;
	}

}
