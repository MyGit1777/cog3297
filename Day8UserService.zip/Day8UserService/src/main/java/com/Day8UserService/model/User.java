package com.Day8UserService.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import ch.qos.logback.core.joran.spi.NoAutoStart;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class User {
	
	@Id
	private long userId;
	private String firstName;

	private String lastName;

	private String email;
	private Long departmentId;


}
