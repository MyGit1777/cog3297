package com.Day8UserService.VO;

import javax.persistence.Entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Department {

	private long deptId;
	private String deptName;

	private String deptAddress;

	private String deptCode;

}
