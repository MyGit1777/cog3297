package com.Day8UserService.VO;

import com.Day8UserService.model.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RestTemplateVO {
	private User user;
	private Department department;

}
