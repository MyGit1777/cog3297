package com.Day8UserService.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Day8UserService.model.User;


public interface UserRepository extends JpaRepository<User, Long>  {
	
public User findUByuserId(Long userId);

}

