import java.util.List;

import com.Day6Exceptions.model.Customer;


public interface CustomerService {

	public List<Customer> getCustomer();

	public Customer addCustomer(Customer course);

	public Customer updateCustomer(Customer course);

	public void deleteCustomer(Integer id);
}
