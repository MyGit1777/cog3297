package com.Day6Exceptions.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	private int custId;
	private String customerName;
	public Customer() {
		
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Customer(int custId, String customerName) {
		super();
		this.custId = custId;
		this.customerName = customerName;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", customerName=" + customerName + ", getCustId()=" + getCustId()
				+ ", getCustomerName()=" + getCustomerName() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	

}
