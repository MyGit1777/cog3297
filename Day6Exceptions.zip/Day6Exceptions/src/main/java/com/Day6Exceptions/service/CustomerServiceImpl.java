package com.Day6Exceptions.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Day6Exceptions.exception.BusinessException;
import com.Day6Exceptions.model.Customer;
import com.Day6Exceptions.repo.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepo;

	@Override
	public List<Customer> getCustomer() {
		// TODO Auto-generated method stub
		return customerRepo.findAll();
	}

	@Override
	public Customer addCustomer(Customer customer) {
		if (customer.getCustomerName().isEmpty() || customer.getCustomerName().isBlank()
				|| customer.getCustomerName().length() == 0) {

			throw new BusinessException("701", "Name is not valid");
		}
		try {

			return customerRepo.save(customer);
		} 
		 catch (IllegalArgumentException ex) {
				throw new BusinessException("702", "Customer is null" + "here is some message"+ ex.getMessage());

			}
		catch (Exception ex) {
			throw new BusinessException("703", "Something went wrong!!!");

		}
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		customerRepo.save(customer);
		return customer;
	}

	@Override
	public void deleteCustomer(Integer id) {
		customerRepo.deleteById(id);

	}

}
