package com.Day6Exceptions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day6ExceptionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
