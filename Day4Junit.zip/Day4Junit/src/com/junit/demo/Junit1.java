package com.junit.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class Junit1 {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

		System.out.println("This is not yet implemented");
	}

	@Test
	void test() {
		fail("Not yet implemented");
	}

	@Test
	void testMultiplyMethod() {

		int sum = Calculator.add(3, 5);
		System.out.println("This is addition result:" + sum);
		Assertions.assertEquals(8, sum);

	}

	@Test
	void testAddMethod() {
		int multiplication = Calculator.multiply(3, 5);
		System.out.println("This is mutiplication result:" + multiplication);
		Assertions.assertEquals(8, multiplication);

	}
	
	@Test
	void testSomeJunitStuff() {
		System.out.println("This is addition result:");
//		Assertions.assertTrue(5>3);
//		Assertions.assertFalse(5>6);
//		
//		
//		Calculator cal = null;
//		Calculator cal1 = new Calculator();
//		Assertions.assertNull(cal);
//		Assertions.assertNotNull(cal1);
		
		String str = "Avinash";
		String str1 = new String("Avinash");
		Assertions.assertNotSame(str, str1);
		

		
		

		
		

	}
}
