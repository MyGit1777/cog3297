package com.junit.demo;

public class Calculator {

	public static int multiply(int a, int b) {

		return a + b;
	}

	public static int add(int a, int b) {

		return a + b;
	}

	public static int subtract(int a, int b) {

		return a - b;
	}

	public int divide(int a, int b) {

		return a / b;
	}
}
