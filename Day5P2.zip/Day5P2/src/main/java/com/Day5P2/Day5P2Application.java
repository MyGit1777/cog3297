package com.Day5P2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day5P2Application {

	public static void main(String[] args) {
		SpringApplication.run(Day5P2Application.class, args);
	}

}
