package com.Day5P2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Day5P2.model.Student;
import com.Day5P2.service.StudentServiceImpl;

@RestController
public class StudentController {

	@Autowired
	private StudentServiceImpl studentImpl;

	@GetMapping("/student")
	public List<Student> getAllStudents() {
		return this.studentImpl.geStudents();

	}

	@PostMapping("/student/create")
	public Student addNewStudent(@RequestBody Student st) {
		return this.studentImpl.addStudent(st);

	}

	@PutMapping("/student/update/{id}")
	public Student updateExistingStudent(@RequestBody Student st) {

		return this.studentImpl.updateStudent(st);

	}

	@DeleteMapping("/student/delete/{id}")
	public ResponseEntity<HttpStatus> deleteExistingStudent(@PathVariable Integer id) {

		try {
			this.studentImpl.deleteStudent(id);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
