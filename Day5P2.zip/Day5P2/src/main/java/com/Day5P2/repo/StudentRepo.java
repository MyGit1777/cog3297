package com.Day5P2.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Day5P2.model.Student;

public interface StudentRepo extends JpaRepository<Student, Integer> {

}
