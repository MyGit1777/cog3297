package com.Day5P2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Day5P2.model.Student;
import com.Day5P2.repo.StudentRepo;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepo studentRepo;

	@Override
	public List<Student> geStudents() {
		return studentRepo.findAll();
	}

	@Override
	public Student addStudent(Student student) {
		studentRepo.save(student);
		return student;
	}

	@Override
	public Student updateStudent(Student student) {
		studentRepo.save(student);
		return student;
	}

	@Override
	public void deleteStudent(Integer id) {
		studentRepo.deleteById(id);

	}
}
