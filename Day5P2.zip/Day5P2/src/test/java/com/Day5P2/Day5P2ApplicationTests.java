package com.Day5P2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day5P2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
