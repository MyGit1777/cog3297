package com.Day6Security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day6SecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
