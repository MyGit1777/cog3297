package com.Day6Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day6SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day6SecurityApplication.class, args);
	}

}
