package com.Day6Security.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Day6Security.model.User;
import com.Day6Security.repo.UserRepo;

@org.springframework.stereotype.Controller
public class Controller {
	@Autowired
	UserRepo userRepo;
	
	
	@GetMapping("/")
	public String welcomeToSecurity() {
		return "myHome.jsp";

	}

	@GetMapping("/user")
	public List<User> getUser() {
		
		return userRepo.findAll();

	}
	@PostMapping("/user")
	public User addUser(@RequestBody User user) {
		
		return userRepo.save(user);

	}
	@RequestMapping("/login")
	public String loginPage() {
		
		return "login.jsp";

	}
	@RequestMapping("/logout-success")
	public String logoutPage() {
		
		return "logout.jsp";

	}
}
