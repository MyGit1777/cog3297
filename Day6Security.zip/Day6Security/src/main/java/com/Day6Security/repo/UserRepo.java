package com.Day6Security.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Day6Security.model.User;



public interface UserRepo extends JpaRepository<User, Long>{

	User findByUserName(String username);

}
