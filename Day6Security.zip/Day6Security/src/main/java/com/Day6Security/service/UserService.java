package com.Day6Security.service;


import com.Day6Security.model.User;


public interface UserService {
	

	public User addStudent(User user);


}
