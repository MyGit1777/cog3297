/*
TSC filename.ts  // To compile
node filename.js  // to run

# 👇️ generate tsconfig.json file
npx --package typescript tsc --init

# 👇️ show typescript version
npx --package typescript tsc --version
*/

//Creating variable
var msg: String = "Welcome to TS";
console.log(msg);

//Class
class Welcome {
  greet(): void {

    console.log("This is TS !!!");
  }
}

//Creating object
var wel = new Welcome();
wel.greet();