
//Function with argument
function findSquare(a: number) {
  console.log("Square of two numbers is:" + a * a);
}
/*
function findSquare(a) { 
  console.log("Square of two numbers is:" + a*a);  
}
*/
findSquare(12);

//Array

var programmingLanguages: string[];
programmingLanguages = ["Java", "Kotlin", "Ruby"]
console.log(programmingLanguages[0]);
console.log(programmingLanguages[1]);

//Iterating array

var a: String;
for (a in programmingLanguages) {
  console.log(programmingLanguages[a])
}

var nums: number[] = [1001, 1002, 1003, 1004]
nums.forEach(function (no) {
  console.log(no)
});

//Interface

interface Car {
  name: string,
  mileage: number,

  run: () => string
}

var audi: Car = {
  name: "Hundai",
  mileage: 25,
  run: (): string => { return "Audi running" }
}

console.log("Customer Object ")
console.log(audi.name)
console.log(audi.mileage)
console.log(audi.run())


