var msg = "Welcome to TS";
console.log(msg);
var Welcome = /** @class */ (function () {
    function Welcome() {
    }
    Welcome.prototype.greet = function () {
        console.log("This is TS !!!");
    };
    return Welcome;
}());
var wel = new Welcome();
wel.greet();
