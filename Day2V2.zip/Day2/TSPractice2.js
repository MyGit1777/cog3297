function findSquare(a) {
    console.log("Square of two numbers is:" + a * a);
}
findSquare(12);
