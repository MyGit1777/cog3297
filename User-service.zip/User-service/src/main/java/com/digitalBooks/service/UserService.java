package com.digitalBooks.service;

import java.util.Optional;

import com.digitalBooks.components.User;

public interface UserService {
	
	public Optional<User> getUser(int userId);

}
