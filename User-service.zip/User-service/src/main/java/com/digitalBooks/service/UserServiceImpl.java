package com.digitalBooks.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.digitalBooks.components.User;
@Service
public class UserServiceImpl implements UserService {

	
	List<User> users = List.of(new User(1, "Avinash"),new User(2, "Marc") );
	

	
	@Override
	public Optional<User> getUser(int userId) {
		return users.stream().filter(u->u.getUserId() == (userId)).findAny();
	}

}
